import React from 'react';

function Home() {
  return (
    <div className='page'>
      <h1>Home</h1>
    </div>
  );
}

export default Home;
