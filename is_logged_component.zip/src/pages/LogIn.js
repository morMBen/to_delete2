import React from 'react';

function LogIn() {
  return (
    <div className='page'>
      <div className='form'>
        <h1>Log In</h1>
        <input />
        <input />
        <div>
          <button>Log In</button>
          <button>Cancel</button>
        </div>
      </div>
    </div>
  );
}

export default LogIn;
