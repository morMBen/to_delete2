import React from 'react';

function page404() {
  return (
    <div className='page'>
      <h1>404</h1>
    </div>
  );
}

export default page404;
